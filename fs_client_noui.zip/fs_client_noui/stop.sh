ps -ef | grep finalspeed_client-NOUI.jar | grep -v grep | awk '{print $2}' | xargs kill -s 9

