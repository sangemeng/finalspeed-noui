#!/bin/sh
ulimit -s 65535
ulimit -n 65535
logname=server.log
cd /fs_client_noui/
nohup java -jar finalspeed_client-NOUI.jar config.json > $logname 2>&1  &
echo FinalSpeed start,log file: /fs_client_noui/$logname