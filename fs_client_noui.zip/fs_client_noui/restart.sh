#!/bin/sh
cd /fs_client_noui/
sh stop.sh
sh start.sh

